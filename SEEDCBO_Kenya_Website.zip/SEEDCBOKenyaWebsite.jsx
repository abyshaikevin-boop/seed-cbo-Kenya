import React from "react";
import { Phone, Mail, MapPin, Globe } from "lucide-react";
import { motion } from "framer-motion";

export default function SEEDCBOWebsite() {
  return (
    <div>SEED CBO KENYA Website Code Here...</div>
  );
}